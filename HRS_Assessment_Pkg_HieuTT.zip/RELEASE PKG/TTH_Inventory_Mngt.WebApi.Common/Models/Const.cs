﻿namespace TTH_Inventory_Mngt.WebApi.Common.Models
{
    public class Const
    {
        // String Format
        public const string FMT_DATE_TIME_DEFAULT = "yyyyMMddHHmmss";
    }
}
