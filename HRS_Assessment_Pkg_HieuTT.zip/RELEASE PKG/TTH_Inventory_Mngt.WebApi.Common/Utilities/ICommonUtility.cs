namespace TTH_Inventory_Mngt.WebApi.Common.Utilities
{
    /// <summary>
    /// ICommonUtility
    /// </summary>
    public interface ICommonUtility { }
}
